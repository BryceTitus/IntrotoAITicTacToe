TicTacToe game by Kenny Yao, Kyle Muldoon, and Bryce Titus
The goal of this project was to create a working TicTacToe game played by a human player and an AI agent that uses the minimax algorithm.
The program will also include a counter for wins by either the human or AI players, as well as a count of the number of draws.
#How to play the Minimax TicTacToe game
Step 1: Start the game by running the main.py file
Step 2: Pick an X or O for your symbol
Step 3: Type y or n for if you would like to go first
Step 4: Choose your desired location off of the numpad, which corresponds to a grid in this fashion
[1, 2, 3]
[4, 5, 6]
[7, 8, 9]
Step 5: Repeat step 4 until you or the AI win (or there is a draw)
Step 6: Once a win or draw occur, the counter for number of wins will increment
Step 7: Enjoy!

Note: The number of wins will be found in the files of this project, in WinCounter.txt.