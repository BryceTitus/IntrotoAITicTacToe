#https://github.com/Cledersonbc/tic-tac-toe-minimax/blob/master/py_version/minimax.py

#!/usr/bin/env python3
from math import inf as infinity
from random import choice
import platform
import time
from os import system
"""
#An implementation of Tic Tac Toe, using Python.
This software is available under GPL license.
Author: Clederson Cruz
Year: 2017
License: GNU GENERAL PUBLIC LICENSE (GPL)
"""
print(
    "Each grid corresponds to a different number on the numpad, as follows:\n [1 2 3]\n [4 5 6]\n [7 8 9]"
)

Player = -1
AI = +1
tictacboard = [
    [0, 0, 0],
    [0, 0, 0],
    [0, 0, 0],
]


#Function to determine the heuristic value of the state.
#State variable tracks the current 'state' of the board.
#Returns a +1 in event of AI victory, -1 in event of human player victory, 0 if draw
def heuristicEvaluation(state):

  if wins(state, AI):
    score = +1
  elif wins(state, Player):
    score = -1
  else:
    score = 0

  return score


#wins function test for whether or not the AI or human player wins
#The possibilities are:
#1. 3 in a row
#2. 3 in a column
#3. 3 in a diagonal
#State parameter tracks the current 'state' of the board.
#player parameter tracks whether its the turn of the human or AI turn
#Returns true once a player wins
def wins(state, player):
  win_state = [
      [state[0][0], state[0][1], state[0][2]],
      [state[1][0], state[1][1], state[1][2]],
      [state[2][0], state[2][1], state[2][2]],
      [state[0][0], state[1][0], state[2][0]],
      [state[0][1], state[1][1], state[2][1]],
      [state[0][2], state[1][2], state[2][2]],
      [state[0][0], state[1][1], state[2][2]],
      [state[2][0], state[1][1], state[0][2]],
  ]
  if [player, player, player] in win_state:
    return True
  else:
    return False


#game over function tests for whether or not the human or AI players have won
#state parameter tracks the current 'state' of the board.
#returns true once a win happens, be it human or AI
def game_over(state):
  return wins(state, Player) or wins(state, AI)


#empty cells function tests for whether or not there are empty cells
#a list of empty cells are mad
#state parameter tracks the current 'state' of the board.
#returns a list of empty cells
def empty_cells(state):
  cells = []

  for x, row in enumerate(state):
    for y, cell in enumerate(row):
      if cell == 0:
        cells.append([x, y])

  return cells


#A move is valid if the chosen cell (1-9) is empty
#x paramater = x coordinate
#y parameter = y coordinate
#return if true if the board space (x,y) is empty
def valid_move(x, y):
  if [x, y] in empty_cells(tictacboard):
    return True
  else:
    return False


#set move function sets the board space (x,y) to the player
#x parameter = x coordinate
#y parameter = y coordinate
#player parameter = the current player
def set_move(x, y, player):
  if valid_move(x, y):
    tictacboard[x][y] = player
    return True
  else:
    return False


#Minimax function, so that AI player will choose the best move
#state parameter tracks the current 'state' of the board.
#depth parameter tracks the current depth of the minimax algorithm (Depth goes from 0 - 9)
#player parameter tracks whether its the turn of the human or AI turn
#Returns the best move for the AI player in form [best row, best column, best score]
def minimax(state, depth, player):
  if player == AI:
    best_option = [-1, -1, -infinity]
  else:
    best_option = [-1, -1, +infinity]

  if depth == 0 or game_over(state):
    score = heuristicEvaluation(state)
    return [-1, -1, score]

  for cell in empty_cells(state):
    x, y = cell[0], cell[1]
    state[x][y] = player
    score = minimax(state, depth - 1, -player)
    state[x][y] = 0
    score[0], score[1] = x, y

    if player == AI:
      if score[2] > best_option[2]:
        best_option = score  # max value
    else:
      if score[2] < best_option[2]:
        best_option = score  # min value

  return best_option


#cleaning of the console
def clean():
  os_name = platform.system().lower()
  if 'windows' in os_name:
    system('cls')
  else:
    system('clear')


def cleanBoard():

  tictacboard = [
      [0, 0, 0],
      [0, 0, 0],
      [0, 0, 0],
  ]


#printing of the board on console
#state parameter on current state of the board
def render(state, ai_choice, human_choice):
  chars = {-1: human_choice, +1: ai_choice, 0: ' '}
  str_line = '---------------'

  print('\n' + str_line)
  for row in state:
    for cell in row:
      symbol = chars[cell]
      print(f'| {symbol} |', end='')
    print('\n' + str_line)


#AI turn function
#Starts by calling the minimax function if the depth is less than 9
#otherwise random coordinate is chosen
#ai_choice parameter tracks the choice of the AI player
#human_choice parameter tracks the choice of the human player
#return results
def ai_turn(ai_choice, human_choice):
  depth = len(empty_cells(tictacboard))
  if depth == 0 or game_over(tictacboard):
    return

  clean()
  print(f'Computer turn [{ai_choice}]')
  render(tictacboard, ai_choice, human_choice)

  if depth == 9:
    x = choice([0, 1, 2])
    y = choice([0, 1, 2])
  else:
    move = minimax(tictacboard, depth, AI)
    x, y = move[0], move[1]

  set_move(x, y, AI)
  time.sleep(1)


#for player turn function
#human plays by choosing a valid move (ie a cell that hasn't been chosen)
#parameter AI choice is for ai's choice of X or O
#Human choice parameter is for human choice of X or O
#return
def player_turn(ai_choice, human_choice):
  depth = len(empty_cells(tictacboard))
  if depth == 0 or game_over(tictacboard):
    return

  # List of valid moves
  move = -1
  moves = {
      1: [0, 0],
      2: [0, 1],
      3: [0, 2],
      4: [1, 0],
      5: [1, 1],
      6: [1, 2],
      7: [2, 0],
      8: [2, 1],
      9: [2, 2],
  }

  clean()
  print(f'Player turn [{human_choice}]')
  render(tictacboard, ai_choice, human_choice)

  while move < 1 or move > 9:
    try:
      move = int(input('Use numpad (1..9): '))
      coord = moves[move]
      can_move = set_move(coord[0], coord[1], Player)

      if not can_move:
        print('Bad move')
        move = -1
    except (EOFError, KeyboardInterrupt):
      print('Bye')
      exit()
    except (KeyError, ValueError):
      print('Bad choice')


#main function
def main():
  #clean()
  playerScore = 0
  AIScore = 0
  tieScore = 0
  human_choice = ''  # X or O
  ai_choice = ''  # X or O
  first = ''  # if Player is the first

  # Player chooses X or O to play
  while human_choice != 'O' and human_choice != 'X':
    try:
      print('')
      human_choice = input('Choose X or O\nChosen: ').upper()
    except (EOFError, KeyboardInterrupt):
      print('Bye')
      exit()
    except (KeyError, ValueError):
      print('Bad choice')

  # Setting computer's choice
  if human_choice == 'X':
    ai_choice = 'O'
  else:
    ai_choice = 'X'

  # Player may starts first
  clean()
  while first != 'Y' and first != 'N':
    try:
      first = input('First to start?[y/n]: ').upper()
    except (EOFError, KeyboardInterrupt):
      print('Bye')
      exit()
    except (KeyError, ValueError):
      print('Bad choice')

  # Main loop of this game
  while len(empty_cells(tictacboard)) > 0 and not game_over(tictacboard):
    if first == 'N':
      ai_turn(ai_choice, human_choice)
      first = ''

    player_turn(ai_choice, human_choice)
    ai_turn(ai_choice, human_choice)

  if wins(tictacboard, Player):
    clean()
    print(f'Player turn [{human_choice}]')
    render(tictacboard, ai_choice, human_choice)
    print('YOU WIN!')
    playerScore += 1
    file1 = open("WinCounter.txt", "w")
    file1.write('Win Count: %d' % playerScore)
    file1.close()
    exit()

  elif wins(tictacboard, AI):
    clean()
    print(f'Computer turn [{ai_choice}]')
    render(tictacboard, ai_choice, human_choice)
    print('YOU LOSE!')
    AIScore += 1
    file1 = open("WinCounter.txt", "w")
    file1.write('AIScore: %d' % AIScore)
    file1.close()
    exit()

  else:
    clean()
    render(tictacboard, ai_choice, human_choice)
    print('DRAW!')
    tieScore += 1
    file1 = open("WinCounter.txt", "w")
    file1.write('TieScore: %d' % tieScore)
    file1.write('\nPlayerScore: %d' % playerScore)
    file1.write('\nAIScore: %d' % AIScore)
    file1.close()
    exit()



if __name__ == '__main__':
  main()
